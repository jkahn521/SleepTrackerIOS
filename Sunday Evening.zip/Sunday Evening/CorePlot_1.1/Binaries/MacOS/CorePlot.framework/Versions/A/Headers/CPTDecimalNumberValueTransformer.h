#import <Foundation/Foundation.h>

@interface CPTDecimalNumberValueTransformer : NSValueTransformer {
}

@end

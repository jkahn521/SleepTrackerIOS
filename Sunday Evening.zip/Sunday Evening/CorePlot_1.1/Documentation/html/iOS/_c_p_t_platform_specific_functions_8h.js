var _c_p_t_platform_specific_functions_8h =
[
    [ "CPTGetCurrentContext", "_c_p_t_platform_specific_functions_8h.html#a3be5490002256d9807df1586581550b9", null ],
    [ "CPTPopCGContext", "_c_p_t_platform_specific_functions_8h.html#af83544397fc336d1c14e66f2b7e473be", null ],
    [ "CPTPushCGContext", "_c_p_t_platform_specific_functions_8h.html#a749370a9ff558a64e0c8e335d8788dac", null ]
];
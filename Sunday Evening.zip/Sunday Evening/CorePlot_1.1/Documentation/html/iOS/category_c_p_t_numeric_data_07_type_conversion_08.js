var category_c_p_t_numeric_data_07_type_conversion_08 =
[
    [ "convertData:dataType:toData:dataType:", "category_c_p_t_numeric_data_07_type_conversion_08.html#a363bb66468930747a1960786ee1b9925", null ],
    [ "dataByConvertingToDataType:", "category_c_p_t_numeric_data_07_type_conversion_08.html#a3eb25c56b573de7f3b6e90c82c94a15f", null ],
    [ "dataByConvertingToType:sampleBytes:byteOrder:", "category_c_p_t_numeric_data_07_type_conversion_08.html#a4eeb1ac8d6a63ad6b14a7ed67ef51a70", null ],
    [ "swapByteOrderForData:sampleSize:", "category_c_p_t_numeric_data_07_type_conversion_08.html#a9d9b6aad253261c6d1f81715653a26d3", null ]
];
var _c_p_t_legend_8h =
[
    [ "<CPTLegendDelegate>", "protocol_c_p_t_legend_delegate-p.html", "protocol_c_p_t_legend_delegate-p" ],
    [ "CPTLegend", "interface_c_p_t_legend.html", "interface_c_p_t_legend" ],
    [ "CPTLegendNeedsLayoutForPlotNotification", "_c_p_t_legend_8h.html#ga531a1b173c232bc63c207180d2ebd174", null ],
    [ "CPTLegendNeedsRedrawForPlotNotification", "_c_p_t_legend_8h.html#gaa902e90db19b08cf4fb6bd1a0d9cfbd9", null ],
    [ "CPTLegendNeedsReloadEntriesForPlotNotification", "_c_p_t_legend_8h.html#gac6c5bb933c26d69e705301c1290e0450", null ]
];
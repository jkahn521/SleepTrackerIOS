var _c_p_t_platform_specific_functions_8m =
[
    [ "CPTGetCurrentContext", "_c_p_t_platform_specific_functions_8m.html#a3be5490002256d9807df1586581550b9", null ],
    [ "CPTPopCGContext", "_c_p_t_platform_specific_functions_8m.html#af83544397fc336d1c14e66f2b7e473be", null ],
    [ "CPTPushCGContext", "_c_p_t_platform_specific_functions_8m.html#af6d0cffe2f7fd5d5c9b96622d8472eee", null ]
];
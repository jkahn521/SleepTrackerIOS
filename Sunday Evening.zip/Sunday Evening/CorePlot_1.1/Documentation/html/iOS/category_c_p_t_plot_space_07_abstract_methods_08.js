var category_c_p_t_plot_space_07_abstract_methods_08 =
[
    [ "doublePrecisionPlotPoint:forEvent:", "category_c_p_t_plot_space_07_abstract_methods_08.html#a603876ee6cf8bcef05d08dafaca238a1", null ],
    [ "doublePrecisionPlotPoint:forPlotAreaViewPoint:", "category_c_p_t_plot_space_07_abstract_methods_08.html#a82b5a9d6a4ec2e1c26852136dafec971", null ],
    [ "plotAreaViewPointForDoublePrecisionPlotPoint:", "category_c_p_t_plot_space_07_abstract_methods_08.html#a067fe72a5a6181ee7251db05aff0522f", null ],
    [ "plotAreaViewPointForEvent:", "category_c_p_t_plot_space_07_abstract_methods_08.html#ab0e0b6301e1b13e6461b62cfbd2b69da", null ],
    [ "plotAreaViewPointForPlotPoint:", "category_c_p_t_plot_space_07_abstract_methods_08.html#a44bfc5a4d3e11c01346759df6973b00a", null ],
    [ "plotPoint:forEvent:", "category_c_p_t_plot_space_07_abstract_methods_08.html#ae30850cdd0463cf64596383e6020b08f", null ],
    [ "plotPoint:forPlotAreaViewPoint:", "category_c_p_t_plot_space_07_abstract_methods_08.html#a111b243e99d0e85c32f28d216aa6a3ed", null ],
    [ "plotRangeForCoordinate:", "category_c_p_t_plot_space_07_abstract_methods_08.html#a3aa2997fb48c06d37e50ff1d114ad7df", null ],
    [ "scaleBy:aboutPoint:", "category_c_p_t_plot_space_07_abstract_methods_08.html#a769547a1f95a562d9f88bb6967815174", null ],
    [ "scaleToFitPlots:", "category_c_p_t_plot_space_07_abstract_methods_08.html#ac98bd7995f1096cdd32a9df350574daa", null ],
    [ "scaleTypeForCoordinate:", "category_c_p_t_plot_space_07_abstract_methods_08.html#a418989b268a9fa93f37f48e4cba42044", null ],
    [ "setPlotRange:forCoordinate:", "category_c_p_t_plot_space_07_abstract_methods_08.html#a709089f3d44fbe7466910f6bcdf2193e", null ],
    [ "setScaleType:forCoordinate:", "category_c_p_t_plot_space_07_abstract_methods_08.html#aed4e84809aaa825c2e50f83b2a2c34a5", null ]
];
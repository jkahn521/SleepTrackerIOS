var _c_p_t_plot_space_8h =
[
    [ "<CPTPlotSpaceDelegate>", "protocol_c_p_t_plot_space_delegate-p.html", "protocol_c_p_t_plot_space_delegate-p" ],
    [ "CPTPlotSpace", "interface_c_p_t_plot_space.html", "interface_c_p_t_plot_space" ],
    [ "CPTPlotSpace(AbstractMethods)", "category_c_p_t_plot_space_07_abstract_methods_08.html", "category_c_p_t_plot_space_07_abstract_methods_08" ],
    [ "CPTPlotSpaceCoordinateMappingDidChangeNotification", "_c_p_t_plot_space_8h.html#ga23f2cfa5cf45e2998bd8983b9ee2f5cc", null ]
];
var category_c_p_t_theme_07_abstract_methods_08 =
[
    [ "applyThemeToAxisSet:", "category_c_p_t_theme_07_abstract_methods_08.html#a109d674d79ec6908ab860b58a1e6cbe5", null ],
    [ "applyThemeToBackground:", "category_c_p_t_theme_07_abstract_methods_08.html#a4ec9e92f0a8f194ec4f73882cfbb8cef", null ],
    [ "applyThemeToPlotArea:", "category_c_p_t_theme_07_abstract_methods_08.html#a9b8a05bfd892bac23f5f5af636caf71d", null ],
    [ "newGraph", "category_c_p_t_theme_07_abstract_methods_08.html#a62847df437e0cb5e1f00251f9e5f3ff7", null ]
];
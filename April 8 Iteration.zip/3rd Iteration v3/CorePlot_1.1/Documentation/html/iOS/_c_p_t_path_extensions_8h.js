var _c_p_t_path_extensions_8h =
[
    [ "AddRoundedRectPath", "_c_p_t_path_extensions_8h.html#a2ac9a4c4f33c339882f822e536e37401", null ],
    [ "CreateRoundedRectPath", "_c_p_t_path_extensions_8h.html#ad7c2b85f72968e82d61a25876fc7e9e0", null ]
];
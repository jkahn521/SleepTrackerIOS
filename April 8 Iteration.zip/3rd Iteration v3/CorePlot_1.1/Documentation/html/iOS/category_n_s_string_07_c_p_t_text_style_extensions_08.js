var category_n_s_string_07_c_p_t_text_style_extensions_08 =
[
    [ "drawInRect:withTextStyle:inContext:", "category_n_s_string_07_c_p_t_text_style_extensions_08.html#ac14ef8f1450a4b80e9fa0cdb835041f0", null ],
    [ "sizeWithTextStyle:", "category_n_s_string_07_c_p_t_text_style_extensions_08.html#a2443616a0293d3fa5a4a21c6a75be489", null ]
];
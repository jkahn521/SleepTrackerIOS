var category_c_p_t_color_07_c_p_t_platform_specific_color_extensions_08 =
[
    [ "uiColor", "category_c_p_t_color_07_c_p_t_platform_specific_color_extensions_08.html#a47cd72bec7f2ba5ae09e6c6c143e9e9e", null ]
];
var _c_p_t_text_layer_8m =
[
    [ "kCPTTextLayerMarginWidth", "_c_p_t_text_layer_8m.html#aac3e77177bea87569a70ef179cab5291", null ]
];
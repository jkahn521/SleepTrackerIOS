var _c_p_t_legend_8m =
[
    [ "CPTLegendNeedsLayoutForPlotNotification", "_c_p_t_legend_8m.html#ga531a1b173c232bc63c207180d2ebd174", null ],
    [ "CPTLegendNeedsRedrawForPlotNotification", "_c_p_t_legend_8m.html#gaa902e90db19b08cf4fb6bd1a0d9cfbd9", null ],
    [ "CPTLegendNeedsReloadEntriesForPlotNotification", "_c_p_t_legend_8m.html#gac6c5bb933c26d69e705301c1290e0450", null ]
];
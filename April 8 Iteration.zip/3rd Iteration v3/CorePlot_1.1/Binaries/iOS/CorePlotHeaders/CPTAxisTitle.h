#import "CPTAxisLabel.h"
#import <Foundation/Foundation.h>

@interface CPTAxisTitle : CPTAxisLabel {
}

@end

var category_c_p_t_graph_07_abstract_factory_methods_08 =
[
    [ "newAxisSet", "category_c_p_t_graph_07_abstract_factory_methods_08.html#ad29ea84f5fb77006c0d0a6860401450e", null ],
    [ "newPlotSpace", "category_c_p_t_graph_07_abstract_factory_methods_08.html#ad79661155d109f17acf4b39cb11b7a56", null ]
];
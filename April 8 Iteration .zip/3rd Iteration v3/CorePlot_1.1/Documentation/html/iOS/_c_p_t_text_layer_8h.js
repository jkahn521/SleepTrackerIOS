var _c_p_t_text_layer_8h =
[
    [ "CPTTextLayer", "interface_c_p_t_text_layer.html", "interface_c_p_t_text_layer" ],
    [ "kCPTTextLayerMarginWidth", "_c_p_t_text_layer_8h.html#aac3e77177bea87569a70ef179cab5291", null ]
];
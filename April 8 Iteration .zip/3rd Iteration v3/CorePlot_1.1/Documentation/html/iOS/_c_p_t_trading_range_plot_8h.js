var _c_p_t_trading_range_plot_8h =
[
    [ "<CPTTradingRangePlotDataSource>", "protocol_c_p_t_trading_range_plot_data_source-p.html", "protocol_c_p_t_trading_range_plot_data_source-p" ],
    [ "<CPTTradingRangePlotDelegate>", "protocol_c_p_t_trading_range_plot_delegate-p.html", "protocol_c_p_t_trading_range_plot_delegate-p" ],
    [ "CPTTradingRangePlot", "interface_c_p_t_trading_range_plot.html", "interface_c_p_t_trading_range_plot" ],
    [ "CPTTradingRangePlotField", "_c_p_t_trading_range_plot_8h.html#a81f1f0a945c498402cfe046428777624", [
      [ "CPTTradingRangePlotFieldX", "_c_p_t_trading_range_plot_8h.html#a81f1f0a945c498402cfe046428777624a4bacbd0b64733a17914687b2d4d3fcda", null ],
      [ "CPTTradingRangePlotFieldOpen", "_c_p_t_trading_range_plot_8h.html#a81f1f0a945c498402cfe046428777624a655989fbfd87a5c60558d059ccce3445", null ],
      [ "CPTTradingRangePlotFieldHigh", "_c_p_t_trading_range_plot_8h.html#a81f1f0a945c498402cfe046428777624afde22423a8e033af1a92af7714fafbff", null ],
      [ "CPTTradingRangePlotFieldLow", "_c_p_t_trading_range_plot_8h.html#a81f1f0a945c498402cfe046428777624adaf48dd581316e023847d12e65ad9c2b", null ],
      [ "CPTTradingRangePlotFieldClose", "_c_p_t_trading_range_plot_8h.html#a81f1f0a945c498402cfe046428777624a17b56d2f5fd676f2f40a32c707a0600c", null ]
    ] ],
    [ "CPTTradingRangePlotStyle", "_c_p_t_trading_range_plot_8h.html#a45133c80b4a14e2720f25ebcc3d19ea9", [
      [ "CPTTradingRangePlotStyleOHLC", "_c_p_t_trading_range_plot_8h.html#a45133c80b4a14e2720f25ebcc3d19ea9a1577be7fb34f7364efc4006066bb6d88", null ],
      [ "CPTTradingRangePlotStyleCandleStick", "_c_p_t_trading_range_plot_8h.html#a45133c80b4a14e2720f25ebcc3d19ea9a3d54a828cf54db92e940948bfe7d3076", null ]
    ] ],
    [ "CPTTradingRangePlotBindingCloseValues", "_c_p_t_trading_range_plot_8h.html#afc476a911fbf3eba1e7daf31ad5c5f27", null ],
    [ "CPTTradingRangePlotBindingDecreaseFills", "_c_p_t_trading_range_plot_8h.html#a823dd852225cb78ef545d50fa74c0097", null ],
    [ "CPTTradingRangePlotBindingDecreaseLineStyles", "_c_p_t_trading_range_plot_8h.html#ad63deec419ad5017e7a677de4cef450a", null ],
    [ "CPTTradingRangePlotBindingHighValues", "_c_p_t_trading_range_plot_8h.html#a306d6a52959ac8bea1230ef5305e8636", null ],
    [ "CPTTradingRangePlotBindingIncreaseFills", "_c_p_t_trading_range_plot_8h.html#a5c3e3e9b06e7ba491ecd5bd98aac091c", null ],
    [ "CPTTradingRangePlotBindingIncreaseLineStyles", "_c_p_t_trading_range_plot_8h.html#a6d25c69831bde5aedd4564bccc13b734", null ],
    [ "CPTTradingRangePlotBindingLineStyles", "_c_p_t_trading_range_plot_8h.html#a0365781ece8d658eb0eaf822dbd6dcd6", null ],
    [ "CPTTradingRangePlotBindingLowValues", "_c_p_t_trading_range_plot_8h.html#a50d2cb897e004a1cf8d6af5635daaae0", null ],
    [ "CPTTradingRangePlotBindingOpenValues", "_c_p_t_trading_range_plot_8h.html#a79233b77eb1664118f183720e60cf03a", null ],
    [ "CPTTradingRangePlotBindingXValues", "_c_p_t_trading_range_plot_8h.html#a19d17ef5e84a7a36c4c3fc05aa552348", null ]
];
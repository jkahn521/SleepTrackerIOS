var _c_p_t_plot_range_8h =
[
    [ "CPTPlotRange", "interface_c_p_t_plot_range.html", "interface_c_p_t_plot_range" ],
    [ "CPTPlotRangeComparisonResult", "_c_p_t_plot_range_8h.html#ae9eb655c44063efd03253fb7f5ed8e34", [
      [ "CPTPlotRangeComparisonResultNumberBelowRange", "_c_p_t_plot_range_8h.html#ae9eb655c44063efd03253fb7f5ed8e34a0df0dfdbdaac682ab8222931c2edcc43", null ],
      [ "CPTPlotRangeComparisonResultNumberInRange", "_c_p_t_plot_range_8h.html#ae9eb655c44063efd03253fb7f5ed8e34aaeca9805478134f36dd1ec1dd0372f35", null ],
      [ "CPTPlotRangeComparisonResultNumberAboveRange", "_c_p_t_plot_range_8h.html#ae9eb655c44063efd03253fb7f5ed8e34a11f1d4e2513b89d49806e52a3e2472ca", null ]
    ] ]
];
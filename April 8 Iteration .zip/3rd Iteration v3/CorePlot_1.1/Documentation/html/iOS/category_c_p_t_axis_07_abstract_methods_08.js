var category_c_p_t_axis_07_abstract_methods_08 =
[
    [ "drawBackgroundBandsInContext:", "category_c_p_t_axis_07_abstract_methods_08.html#a26e0b9f86de20b0fd293e98e6850154b", null ],
    [ "drawBackgroundLimitsInContext:", "category_c_p_t_axis_07_abstract_methods_08.html#a3a7f29c9c8f34165fd3b1635fcac3114", null ],
    [ "drawGridLinesInContext:isMajor:", "category_c_p_t_axis_07_abstract_methods_08.html#afc4a9b3419504af68296616ce8a95572", null ],
    [ "viewPointForCoordinateDecimalNumber:", "category_c_p_t_axis_07_abstract_methods_08.html#af25bf15f120918facdcd1a73ff0f963c", null ]
];
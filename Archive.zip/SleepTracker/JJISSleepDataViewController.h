//
//  JJISSleepDataViewController.h
//  SleepTracker
//
//  Created by Jason Kahn on 2/19/13.
//  Copyright (c) 2013 Jason Kahn. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface JJISSleepDataViewController : UIViewController

@property (weak, nonatomic) IBOutlet UITableView *SleepDataTable;



@end

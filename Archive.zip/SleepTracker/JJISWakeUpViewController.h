//
//  JJISWakeUpViewController.h
//  SleepTracker
//
//  Created by Jason Kahn on 2/19/13.
//  Copyright (c) 2013 Jason Kahn. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface JJISWakeUpViewController : UIViewController

@end

//
//  SleepTrackerTests.h
//  SleepTrackerTests
//
//  Created by Jason Kahn on 2/18/13.
//  Copyright (c) 2013 Jason Kahn. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface SleepTrackerTests : SenTestCase

@end
